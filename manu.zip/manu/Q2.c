#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, current_head, total_head_movement = 0;

    // Accept number of disk blocks and request string
    printf("Enter the total number of disk requests: ");
    scanf("%d", &n);

    int requests[n];

    printf("Enter the disk request string: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requests[i]);
    }

    // Accept the current head position
    printf("Enter the current head position: ");
    scanf("%d", &current_head);

    int served[n];
    for (int i = 0; i < n; i++) {
        served[i] = 0;  // Mark all requests as unserved
    }

    // Simulate SSTF Disk Scheduling
    printf("\nRequest served in the order: ");
    while (1) {
        int min_diff = 9999, min_index = -1;
        
        // Find the request with the shortest seek time (SSTF)
        for (int i = 0; i < n; i++) {
            if (!served[i]) {
                int diff = abs(requests[i] - current_head);
                if (diff < min_diff) {
                    min_diff = diff;
                    min_index = i;
                }
            }
        }

        // If all requests are served, break the loop
        if (min_index == -1) break;

        // Serve the request and update the total head movement
        served[min_index] = 1;
        total_head_movement += min_diff;
        current_head = requests[min_index];

        // Display the request served
        printf("%d ", requests[min_index]);
    }

    printf("\nTotal head movement: %d\n", total_head_movement);

    return 0;
}
