#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100

// Function to display the bit vector
void showBitVector(int disk[], int n) {
    printf("Bit Vector: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }
    printf("\n");
}

// Function to display the directory of allocated files
void showDirectory(int disk[], int n) {
    printf("Directory (Allocated blocks):\n");
    for (int i = 0; i < n; i++) {
        if (disk[i] != -1) {
            printf("File in Block %d allocated at %d\n", disk[i], i);
        }
    }
}

// Function to delete a file by setting the allocated blocks to -1
void deleteFile(int disk[], int n, int block) {
    if (disk[block] == -1) {
        printf("No file allocated at block %d\n", block);
        return;
    }
    disk[block] = -1; // Mark the block as free
    printf("File deleted from block %d\n", block);
}

// Main menu function
int main() {
    int n, choice, block;
    int disk[MAX_BLOCKS];

    printf("Enter the number of disk blocks: ");
    scanf("%d", &n);

    // Initialize disk blocks with -1 (free)
    for (int i = 0; i < n; i++) {
        disk[i] = -1;
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Show Bit Vector\n");
        printf("2. Show Directory\n");
        printf("3. Delete File\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                showBitVector(disk, n);
                break;
            case 2:
                showDirectory(disk, n);
                break;
            case 3:
                printf("Enter block number to delete file from: ");
                scanf("%d", &block);
                if (block >= 0 && block < n) {
                    deleteFile(disk, n, block);
                } else {
                    printf("Invalid block number\n");
                }
                break;
            case 4:
                printf("Exiting the program.\n");
                exit(0);
            default:
                printf("Invalid choice, please try again.\n");
        }
    }
    return 0;
}
