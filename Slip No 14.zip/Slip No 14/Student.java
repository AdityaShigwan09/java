import SY.SYMarks;
import TY.TYMarks;

class Student {
    private int rollNumber;
    private String name;
    private SYMarks syMarks;
    private TYMarks tyMarks;

    public Student(int rollNumber, String name, SYMarks syMarks, TYMarks tyMarks) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.syMarks = syMarks;
        this.tyMarks = tyMarks;
    }

    public String calculateGrade() {
        int totalSYComputer = syMarks.getComputerTotal();
        int totalTYComputer = tyMarks.getTheory(); // Assuming 'Theory' is the computer subject in TY

        int totalMarks = totalSYComputer + totalTYComputer;
        String grade;

        if (totalMarks >= 70) {
            grade = "A";
        } else if (totalMarks >= 60) {
            grade = "B";
        } else if (totalMarks >= 50) {
            grade = "C";
        } else if (totalMarks >= 40) {
            grade = "Pass Class";
        } else {
            grade = "FAIL";
        }

        return String.format("Roll Number: %d, Name: %s, Total Marks: %d, Grade: %s",
                rollNumber, name, totalMarks, grade);
    }
}