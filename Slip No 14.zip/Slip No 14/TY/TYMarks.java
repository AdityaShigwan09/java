package TY;

public class TYMarks {
    private int theory;
    private int practicals;

    public TYMarks(int theory, int practicals) {
        this.theory = theory;
        this.practicals = practicals;
    }

    public int getTheory() {
        return theory;
    }

    public int getPracticals() {
        return practicals;
    }
}
