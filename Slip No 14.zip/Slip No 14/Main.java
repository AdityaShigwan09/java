import SY.SYMarks;
import TY.TYMarks;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of students: ");
        int n = scanner.nextInt();
        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for student " + (i + 1) + ":");
            System.out.print("Roll Number: ");
            int rollNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter SY Computer Total: ");
            int syComputer = scanner.nextInt();
            System.out.print("Enter SY Maths Total: ");
            int syMaths = scanner.nextInt();
            System.out.print("Enter SY Electronics Total: ");
            int syElectronics = scanner.nextInt();
            SYMarks syMarks = new SYMarks(syComputer, syMaths, syElectronics);

            System.out.print("Enter TY Theory Marks: ");
            int tyTheory = scanner.nextInt();
            System.out.print("Enter TY Practicals Marks: ");
            int tyPracticals = scanner.nextInt();
            TYMarks tyMarks = new TYMarks(tyTheory, tyPracticals);

            students[i] = new Student(rollNumber, name, syMarks, tyMarks);
        }

        System.out.println("\nStudent Results:");
        for (Student student : students) {
            System.out.println(student.calculateGrade());
        }

        scanner.close();
    }
}