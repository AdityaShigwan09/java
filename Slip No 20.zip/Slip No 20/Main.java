import OPERATION.Addition;
import OPERATION.Maximum;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Test Addition class
        System.out.print("Enter first integer for addition: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter second integer for addition: ");
        int num2 = scanner.nextInt();

        Addition addition = new Addition();
        System.out.println("Sum: " + addition.add(num1, num2));

        System.out.print("Enter first float for subtraction: ");
        float float1 = scanner.nextFloat();
        System.out.print("Enter second float for subtraction: ");
        float float2 = scanner.nextFloat();
        System.out.println("Difference: " + addition.subtract(float1, float2));

        // Test Maximum class
        System.out.print("Enter first integer for maximum: ");
        int maxNum1 = scanner.nextInt();
        System.out.print("Enter second integer for maximum: ");
        int maxNum2 = scanner.nextInt();

        Maximum maximum = new Maximum();
        System.out.println("Maximum: " + maximum.max(maxNum1, maxNum2));

        scanner.close();
    }
}