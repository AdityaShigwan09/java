// Slip 20
// Q1) Write a Program to illustrate multilevel Inheritance such that country is inherited from continent. 
// State is inherited from country. Display the place, state, country and continent.


import java.util.Scanner;

class Continent {
    private String name;

    public Continent(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class Country extends Continent {
    private String countryName;

    public Country(String continentName, String countryName) {
        super(continentName); // Call the constructor of the superclass
        this.countryName = countryName;
    }

    public String getCountryName() {
        return countryName;
    }
}

class State extends Country {
    private String stateName;

    public State(String continentName, String countryName, String stateName) {
        super(continentName, countryName); // Call the constructor of the superclass
        this.stateName = stateName;
    }

    public String getStateName() {
        return stateName;
    }

    public void displayInfo(String place) {
        System.out.println("Place: " + place);
        System.out.println("State: " + getStateName());
        System.out.println("Country: " + getCountryName());
        System.out.println("Continent: " + getName());
    }


}


class Text{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the place: ");
        String place = scanner.nextLine();

        System.out.print("Enter the continent: ");
        String continent = scanner.nextLine();

        System.out.print("Enter the country: ");
        String country = scanner.nextLine();

        System.out.print("Enter the state: ");
        String state = scanner.nextLine();

        // Create a State object
        State myState = new State(continent, country, state);

        // Display the information
        myState.displayInfo(place);

        scanner.close();
    }
}