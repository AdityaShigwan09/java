package OPERATION;

public class Maximum {
    // Method to find the maximum of two integers
    public int max(int a, int b) {
        return (a > b) ? a : b;
    }
}