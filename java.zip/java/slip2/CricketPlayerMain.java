import java.util.Arrays;
import java.util.Scanner;

class CricketPlayer {
    String name;
    int noOfInnings;
    int noOfTimesNotOut;
    int totalRuns;
    double batAvg;

    // Constructor
    public CricketPlayer(String name, int noOfInnings, int noOfTimesNotOut, int totalRuns) {
        this.name = name;
        this.noOfInnings = noOfInnings;
        this.noOfTimesNotOut = noOfTimesNotOut;
        this.totalRuns = totalRuns;
        this.batAvg = avg(noOfInnings, noOfTimesNotOut, totalRuns);
    }

    // Static method to calculate batting average
    public static double avg(int noOfInnings, int noOfTimesNotOut, int totalRuns) {
        if (noOfInnings - noOfTimesNotOut == 0) {
            return 0; // Avoid division by zero
        }
        return (double) totalRuns / (noOfInnings - noOfTimesNotOut);
    }

    // Static method to sort CricketPlayer array by batting average
    public static void sort(CricketPlayer[] players) {
        Arrays.sort(players, (p1, p2) -> Double.compare(p2.batAvg, p1.batAvg));
    }

    // Method to display player details
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("No. of Innings: " + noOfInnings);
        System.out.println("No. of Times Not Out: " + noOfTimesNotOut);
        System.out.println("Total Runs: " + totalRuns);
        System.out.println("Batting Average: " + batAvg);
        System.out.println();
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of players: ");
        int n = scanner.nextInt();

        CricketPlayer[] players = new CricketPlayer[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter player " + (i + 1) + " name: ");
            String name = scanner.next();

            System.out.print("Enter no. of innings for " + name + ": ");
            int noOfInnings = scanner.nextInt();

            System.out.print("Enter no. of times not out for " + name + ": ");
            int noOfTimesNotOut = scanner.nextInt();

            System.out.print("Enter total runs for " + name + ": ");
            int totalRuns = scanner.nextInt();

            players[i] = new CricketPlayer(name, noOfInnings, noOfTimesNotOut, totalRuns);
        }

        sort(players);

        System.out.println("Player Details in Sorted Order by Batting Average:");
        for (CricketPlayer player : players) {
            player.display();
        }

        scanner.close();
    }
}