import java.util.Scanner;

class Sphere {
    private double radius;

    // Constructor
    public Sphere(double radius) {
        this.radius = radius;
    }

    // Method to calculate surface area
    public double surfaceArea() {
        return 4 * Math.PI * (radius * radius);
    }

    // Method to calculate volume
    public double volume() {
        return (4.0 / 3) * Math.PI * (radius * radius * radius);
    }

    // Method to display results
    public void display() {
        System.out.printf("For a sphere with radius %.2f:%n", radius);
        System.out.printf("Surface Area: %.2f%n", surfaceArea());
        System.out.printf("Volume: %.2f%n", volume());
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the sphere: ");
        double radius = scanner.nextDouble();

        // Create a Sphere object
        Sphere sphere = new Sphere(radius);

        // Display the surface area and volume
        sphere.display();

        scanner.close();
    }
}