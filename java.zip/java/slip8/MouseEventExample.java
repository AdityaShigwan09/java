import java.awt.event.*;
import javax.swing.*;

public class MouseEventExample extends JFrame implements MouseMotionListener, MouseListener {
    private JTextField textField;

    // Constructor to set up the GUI
    public MouseEventExample() {
        // Set up the frame
        setTitle("Mouse Event Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Create a text field to display mouse click position
        textField = new JTextField();
        textField.setBounds(50, 200, 300, 30);
        textField.setEditable(false);
        add(textField);

        // Add mouse listeners
        addMouseMotionListener(this);
        addMouseListener(this);
    }

    // Mouse motion event handler
    @Override
    public void mouseMoved(MouseEvent e) {
        // Optionally, you can handle mouse movement here
        // For example, we can change the title to show current mouse position
        setTitle("Mouse Position: (" + e.getX() + ", " + e.getY() + ")");
    }

    // Mouse clicked event handler
    @Override
    public void mouseClicked(MouseEvent e) {
        // Display the position of the mouse click in the text field
        textField.setText("Mouse Clicked at: (" + e.getX() + ", " + e.getY() + ")");
    }

    // Unused mouse event methods
    @Override
    public void mouseDragged(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MouseEventExample example = new MouseEventExample();
            example.setVisible(true);
        });
    }
}