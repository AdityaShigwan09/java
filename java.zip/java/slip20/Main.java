import Operation.Addition;
import Operation.Maximum;

public class Main {
    public static void main(String[] args) {
        Addition addition = new Addition();
        Maximum maximum = new Maximum();

        // Using Addition class
        int sum = addition.add(5, 10);
        float difference = addition.subtract(15.5f, 10.2f);
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);

        // Using Maximum class
        int max = maximum.max(20, 30);
        System.out.println("Maximum: " + max);
    }
}