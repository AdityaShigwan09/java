// Base class
class Continent {
    String name;

    public Continent(String name) {
        this.name = name;
    }

    public String getContinentName() {
        return name;
    }
}

// Intermediate class
class Country extends Continent {
    String countryName;

    public Country(String continentName, String countryName) {
        super(continentName);
        this.countryName = countryName;
    }

    public String getCountryName() {
        return countryName;
    }
}

// Derived class
class State extends Country {
    String stateName;

    public State(String continentName, String countryName, String stateName) {
        super(continentName, countryName);
        this.stateName = stateName;
    }

    public String getStateName() {
        return stateName;
    }

    public void displayDetails(String place) {
        System.out.println("Place: " + place);
        System.out.println("State: " + getStateName());
        System.out.println("Country: " + getCountryName());
        System.out.println("Continent: " + getContinentName());
    }
}

// Main class
public class MultilevelInheritance {
    public static void main(String[] args) {
        State state = new State("North America", "United States", "California");
        state.displayDetails("Los Angeles");
    }
}