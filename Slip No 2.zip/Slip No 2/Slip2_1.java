/*Write a program to read the First Name and Last Name of a person, his weight and height using
command line arguments. Calculate the BMI Index which is defined as the individual's body mass
divided by the square of their height.
(Hint : BMI = Wts. In kgs / (ht)2) */

import java.util.Scanner;

 class Slip2_1 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

       
        System.out.print("Enter your weight in kg: ");
        double weight = scanner.nextDouble();

        
        System.out.print("Enter your height in meters: ");
        double height = scanner.nextDouble();

        double bmi = weight / (height * height);

        System.out.printf("\nName :"+ firstName+" "+lastName);
        System.out.printf("\nWeight : "+weight);
        System.out.printf("\nHeight : "+height);
        System.out.printf("\nBMI : "+bmi);

        scanner.close();
    }
}